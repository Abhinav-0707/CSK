
import React, { useState } from 'react';
import { 
  Download, 
  Presentation, 
  FileText, 
  Trash2, 
  ArrowLeft,
  CheckCircle2,
  Cpu,
  Star,
  Zap,
  Layout,
  MessageCircle,
  Loader2
} from 'lucide-react';
import { Curriculum, Slide, TeachingNote } from '../types';
import { geminiService } from '../services/geminiService';

interface CurriculumViewerProps {
  curriculum: Curriculum;
  onBack: () => void;
  onDelete: (id: string) => void;
}

const CurriculumViewer: React.FC<CurriculumViewerProps> = ({ curriculum, onBack, onDelete }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'modules' | 'slides' | 'notes'>('overview');
  const [isGeneratingExtra, setIsGeneratingExtra] = useState(false);
  const [slides, setSlides] = useState<Slide[]>([]);
  const [notes, setNotes] = useState<TeachingNote[]>([]);

  const handleGenerateSlides = async () => {
    setIsGeneratingExtra(true);
    setActiveTab('slides');
    try {
      const generatedSlides = await geminiService.generateSlides(curriculum);
      setSlides(generatedSlides || []);
    } catch (err) {
      console.error(err);
      setSlides([]);
    } finally {
      setIsGeneratingExtra(false);
    }
  };

  const handleGenerateNotes = async () => {
    setIsGeneratingExtra(true);
    setActiveTab('notes');
    try {
      const allNotes = await Promise.all(
        (curriculum.modules || []).slice(0, 3).map(m => geminiService.generateTeachingNotes(m, curriculum.title))
      );
      setNotes(allNotes || []);
    } catch (err) {
      console.error(err);
      setNotes([]);
    } finally {
      setIsGeneratingExtra(false);
    }
  };

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-start">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full transition-all">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 className="text-3xl font-bold">{curriculum.title}</h2>
            <p className="text-slate-400 mt-1">{curriculum.industry} • {curriculum.skillLevel}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={() => onDelete(curriculum.id)} className="p-3 bg-red-500/10 text-red-400 rounded-xl hover:bg-red-500/20 transition-all">
            <Trash2 size={20} />
          </button>
          <button className="px-6 py-3 border border-white/10 rounded-xl font-bold flex items-center gap-2 hover:bg-white/5 transition-all">
            <Download size={20} /> Export JSON
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { id: 'overview', label: 'Overview', icon: Layout },
          { id: 'modules', label: 'Modules', icon: FileText },
          { id: 'slides', label: 'Presentation', icon: Presentation },
          { id: 'notes', label: 'Teaching Notes', icon: MessageCircle },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`p-4 rounded-2xl flex items-center gap-3 transition-all ${
              activeTab === tab.id ? 'gradient-bg text-white' : 'glass text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <tab.icon size={20} />
            <span className="font-semibold">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="glass p-8 rounded-3xl min-h-[400px]">
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-in slide-in-from-left-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Star className="text-yellow-400" /> Course Description
                </h3>
                <p className="text-slate-300 leading-relaxed">{curriculum.description || 'No description available.'}</p>
              </div>
              <div className="space-y-6">
                <div className="glass p-6 rounded-2xl border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-purple-500/20 text-purple-400 rounded-xl">
                      <Cpu size={24} />
                    </div>
                    <div>
                      <p className="text-sm text-slate-400">AI Quality Score</p>
                      <p className="text-2xl font-bold">{curriculum.qualityScore || 0}%</p>
                    </div>
                  </div>
                  <div className="w-16 h-16 rounded-full border-4 border-white/10 flex items-center justify-center font-bold text-lg">
                    {curriculum.qualityScore || 0}
                  </div>
                </div>
                <div className="glass p-6 rounded-2xl border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl">
                      <Zap size={24} />
                    </div>
                    <div>
                      <p className="text-sm text-slate-400">Industry Alignment</p>
                      <p className="text-2xl font-bold">{curriculum.industryAlignment || 0}%</p>
                    </div>
                  </div>
                  <div className="w-16 h-16 rounded-full border-4 border-white/10 flex items-center justify-center font-bold text-lg">
                    {curriculum.industryAlignment || 0}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-white/10">
              <section className="space-y-4">
                <h4 className="font-bold flex items-center gap-2"><CheckCircle2 size={18} className="text-green-400" /> Outcomes</h4>
                <ul className="space-y-2">
                  {(curriculum.outcomes || []).map((o, i) => (
                    <li key={i} className="text-sm text-slate-400">• {o}</li>
                  ))}
                </ul>
              </section>
              <section className="space-y-4">
                <h4 className="font-bold flex items-center gap-2"><FileText size={18} className="text-blue-400" /> Assignments</h4>
                <ul className="space-y-2">
                  {(curriculum.assignments || []).map((a, i) => (
                    <li key={i} className="text-sm text-slate-400">• {a}</li>
                  ))}
                </ul>
              </section>
              <section className="space-y-4">
                <h4 className="font-bold flex items-center gap-2"><Cpu size={18} className="text-purple-400" /> Stack</h4>
                <div className="flex flex-wrap gap-2">
                  {(curriculum.tools || []).map((t, i) => (
                    <span key={i} className="text-xs font-medium px-3 py-1 bg-white/5 rounded-full border border-white/10">{t}</span>
                  ))}
                </div>
              </section>
            </div>
          </div>
        )}

        {activeTab === 'modules' && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
            {(curriculum.modules || []).map((module, idx) => (
              <div key={idx} className="glass p-6 rounded-2xl border-white/5 hover:border-white/10 transition-all">
                <h3 className="text-xl font-bold text-purple-300">Module {idx + 1}: {module.title}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
                  <div>
                    <h4 className="text-sm font-bold uppercase text-slate-500 mb-3 tracking-widest">Key Topics</h4>
                    <ul className="space-y-2">
                      {(module.topics || []).map((t, i) => (
                        <li key={i} className="flex items-center gap-2 text-slate-300">
                          <div className="w-1.5 h-1.5 rounded-full bg-purple-500" /> {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold uppercase text-slate-500 mb-3 tracking-widest">Practical Tasks</h4>
                    <ul className="space-y-2">
                      {(module.practicalTasks || []).map((t, i) => (
                        <li key={i} className="flex items-center gap-2 text-slate-300">
                          <CheckCircle2 size={14} className="text-green-500" /> {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'slides' && (
          <div className="space-y-8 animate-in zoom-in-95 duration-300">
            {slides.length === 0 && !isGeneratingExtra ? (
              <div className="text-center py-20">
                <div className="w-20 h-20 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-purple-400">
                  <Presentation size={40} />
                </div>
                <h3 className="text-2xl font-bold">Generate Visual Presentation</h3>
                <p className="text-slate-400 mt-2 max-w-sm mx-auto">Convert this curriculum into professional slides with speaker notes.</p>
                <button onClick={handleGenerateSlides} className="mt-8 px-8 py-3 gradient-bg rounded-xl font-bold shadow-lg shadow-purple-500/20">
                  Generate Slides Now
                </button>
              </div>
            ) : isGeneratingExtra ? (
              <div className="flex flex-col items-center justify-center py-20 space-y-4">
                <Loader2 size={48} className="animate-spin text-purple-500" />
                <p className="text-xl font-medium">Drafting Slides...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {(slides || []).map((slide, i) => (
                  <div key={i} className="aspect-video glass border-white/10 rounded-xl p-8 flex flex-col justify-between group hover:border-purple-500/50 transition-all">
                    <div>
                      <h4 className="text-lg font-bold text-purple-300 mb-4">{slide.title}</h4>
                      <ul className="space-y-2">
                        {(slide.bullets || []).map((b, bi) => (
                          <li key={bi} className="text-sm text-slate-300 flex gap-2">
                            <span>•</span> {b}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="mt-6 pt-4 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <p className="text-xs font-bold text-slate-500 uppercase mb-2">Speaker Notes</p>
                      <p className="text-xs text-slate-400 italic">{slide.speakerNotes}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-300">
            {notes.length === 0 && !isGeneratingExtra ? (
              <div className="text-center py-20">
                <div className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-blue-400">
                  <MessageCircle size={40} />
                </div>
                <h3 className="text-2xl font-bold">In-depth Teaching Notes</h3>
                <p className="text-slate-400 mt-2 max-w-sm mx-auto">Get comprehensive scripts, examples, and case studies for your lectures.</p>
                <button onClick={handleGenerateNotes} className="mt-8 px-8 py-3 gradient-bg rounded-xl font-bold shadow-lg shadow-purple-500/20">
                  Generate All Notes
                </button>
              </div>
            ) : isGeneratingExtra ? (
              <div className="flex flex-col items-center justify-center py-20 space-y-4">
                <Loader2 size={48} className="animate-spin text-purple-500" />
                <p className="text-xl font-medium">Analyzing Pedagogical Structures...</p>
              </div>
            ) : (
              <div className="space-y-8">
                {(notes || []).map((note, i) => (
                  <div key={i} className="glass p-8 rounded-2xl border-white/5">
                    <h3 className="text-2xl font-bold text-white mb-6">Module: {note.moduleTitle}</h3>
                    <div className="prose prose-invert max-w-none">
                      <p className="text-slate-300 whitespace-pre-wrap">{note.content}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10">
                      <div className="bg-white/5 p-6 rounded-xl border border-white/5">
                        <h4 className="font-bold text-purple-400 mb-4 flex items-center gap-2">
                          <Star size={16} /> Real-World Examples
                        </h4>
                        <ul className="space-y-2">
                          {(note.examples || []).map((ex, exi) => (
                            <li key={exi} className="text-sm text-slate-400 italic">" {ex} "</li>
                          ))}
                        </ul>
                      </div>
                      {note.caseStudy && (
                        <div className="bg-purple-500/5 p-6 rounded-xl border border-purple-500/10">
                          <h4 className="font-bold text-blue-400 mb-4 flex items-center gap-2">
                            <FileText size={16} /> Case Study
                          </h4>
                          <p className="text-sm text-slate-300">{note.caseStudy}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CurriculumViewer;
