
import React from 'react';
import { 
  Plus, 
  Clock, 
  Star, 
  TrendingUp, 
  ArrowRight,
  BookOpen,
  Award,
  Zap,
  // Add missing Sparkles icon to imports
  Sparkles
} from 'lucide-react';
import { Curriculum } from '../types';

interface DashboardProps {
  userName: string;
  curriculums: Curriculum[];
  onCreateNew: () => void;
  onViewHistory: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ userName, curriculums, onCreateNew, onViewHistory }) => {
  const stats = [
    { label: 'Total Curriculums', value: curriculums.length, icon: BookOpen, color: 'text-blue-400' },
    { label: 'Average Quality', value: curriculums.length ? Math.round(curriculums.reduce((acc, c) => acc + c.qualityScore, 0) / curriculums.length) + '%' : '0%', icon: Star, color: 'text-yellow-400' },
    { label: 'Market Alignment', value: curriculums.length ? Math.round(curriculums.reduce((acc, c) => acc + c.industryAlignment, 0) / curriculums.length) + '%' : '0%', icon: TrendingUp, color: 'text-green-400' },
  ];

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Welcome back, {userName}! 👋</h2>
          <p className="text-slate-400 mt-1">Ready to forge some world-class knowledge today?</p>
        </div>
        <button 
          onClick={onCreateNew}
          className="px-6 py-3 gradient-bg rounded-xl font-bold flex items-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-purple-500/20"
        >
          <Plus size={20} />
          Create New Curriculum
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="glass p-6 rounded-2xl border border-white/5 hover:border-white/20 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-400 text-sm">{stat.label}</p>
                <h3 className="text-3xl font-bold mt-2">{stat.value}</h3>
              </div>
              <div className={`p-3 rounded-xl bg-white/5 ${stat.color}`}>
                <stat.icon size={24} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold">Recent Creations</h3>
            <button onClick={onViewHistory} className="text-purple-400 text-sm hover:underline flex items-center gap-1">
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-4">
            {curriculums.length > 0 ? (
              curriculums.slice(0, 3).map((curr) => (
                <div key={curr.id} className="glass p-4 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center text-white shrink-0">
                      <Zap size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold truncate group-hover:text-purple-300 transition-colors">{curr.title}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{curr.industry} • {curr.duration}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold px-2 py-1 rounded bg-purple-500/20 text-purple-300">
                        {curr.qualityScore}% Quality
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="glass p-12 rounded-2xl border border-dashed border-white/20 text-center">
                <p className="text-slate-500">No curriculums created yet. Start forging!</p>
              </div>
            )}
          </div>
        </section>

        <section className="glass p-8 rounded-2xl flex flex-col justify-center items-center text-center space-y-6">
          <div className="w-20 h-20 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400">
            <Sparkles size={40} className="animate-pulse" />
          </div>
          <div>
            <h3 className="text-xl font-bold">AI Strategy Assistant</h3>
            <p className="text-slate-400 mt-2 max-w-xs">
              Let our generative AI help you stay ahead of industry trends and optimize your teaching materials.
            </p>
          </div>
          <button 
            onClick={onCreateNew}
            className="w-full py-4 rounded-xl border border-white/10 hover:bg-white/5 font-semibold transition-all"
          >
            Launch AI Engine
          </button>
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
