
import React, { useState } from 'react';
import { 
  Send, 
  ChevronRight, 
  ChevronLeft, 
  BookText, 
  Users, 
  Trophy, 
  Clock, 
  Globe,
  Loader2
} from 'lucide-react';

interface CurriculumFormProps {
  onGenerate: (data: any) => void;
  isGenerating: boolean;
}

const CurriculumForm: React.FC<CurriculumFormProps> = ({ onGenerate, isGenerating }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    audience: '',
    skillLevel: 'Beginner',
    industry: '',
    duration: '',
    objectives: ''
  });

  const nextStep = () => setStep(prev => Math.min(prev + 1, 2));
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  const progress = (step / 2) * 100;

  return (
    <div className="max-w-4xl mx-auto p-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8">
        <h2 className="text-3xl font-bold">Forge a New Curriculum</h2>
        <p className="text-slate-400 mt-2">Fill in the core parameters, and let AI build the framework.</p>
        
        <div className="w-full bg-white/5 h-2 rounded-full mt-8 overflow-hidden">
          <div 
            className="h-full gradient-bg transition-all duration-500" 
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="glass p-8 rounded-3xl space-y-8 relative overflow-hidden">
        {isGenerating && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex flex-col items-center justify-center space-y-4">
            <Loader2 className="w-12 h-12 text-purple-500 animate-spin" />
            <div className="text-center">
              <h3 className="text-xl font-bold">Forging Your Curriculum...</h3>
              <p className="text-slate-400">Synthesizing industry trends and pedagogical structures.</p>
            </div>
            <div className="w-64 bg-white/10 h-1.5 rounded-full mt-4">
              <div className="h-full gradient-bg animate-pulse w-2/3 rounded-full" />
            </div>
          </div>
        )}

        {step === 1 ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <BookText size={16} /> Course Title
                </label>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="e.g. Advanced Machine Learning for Finance"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  value={formData.title}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Globe size={16} /> Industry Domain
                </label>
                <input
                  type="text"
                  name="industry"
                  required
                  placeholder="e.g. Fintech, Healthcare, Web3"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  value={formData.industry}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Users size={16} /> Target Audience
                </label>
                <input
                  type="text"
                  name="audience"
                  required
                  placeholder="e.g. Engineering Graduates, Professionals"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  value={formData.audience}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Trophy size={16} /> Skill Level
                </label>
                <select
                  name="skillLevel"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all appearance-none"
                  value={formData.skillLevel}
                  onChange={handleChange}
                >
                  <option value="Beginner" className="bg-slate-900">Beginner</option>
                  <option value="Intermediate" className="bg-slate-900">Intermediate</option>
                  <option value="Advanced" className="bg-slate-900">Advanced</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={nextStep}
                disabled={!formData.title || !formData.industry}
                className="px-8 py-3 bg-white/10 rounded-xl font-bold flex items-center gap-2 hover:bg-white/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next Step <ChevronRight size={20} />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                <Clock size={16} /> Course Duration
              </label>
              <input
                type="text"
                name="duration"
                required
                placeholder="e.g. 12 Weeks, 3 Months, Intensive 4-Day Workshop"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                value={formData.duration}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
                <Send size={16} /> Key Learning Objectives
              </label>
              <textarea
                name="objectives"
                required
                rows={4}
                placeholder="List major outcomes you want to achieve..."
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all resize-none"
                value={formData.objectives}
                onChange={handleChange}
              />
            </div>

            <div className="flex justify-between items-center">
              <button
                type="button"
                onClick={prevStep}
                className="px-6 py-3 border border-white/10 rounded-xl font-bold flex items-center gap-2 hover:bg-white/5 transition-all"
              >
                <ChevronLeft size={20} /> Back
              </button>
              <button
                type="submit"
                className="px-10 py-3 gradient-bg rounded-xl font-bold flex items-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-purple-500/20"
              >
                Generate Curriculum <Send size={20} />
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default CurriculumForm;
