
import { Curriculum, User, SavedContent } from '../types';

const STORAGE_KEY = 'curricu_forge_data';

export const storageService = {
  getData: (): SavedContent => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : { curriculums: [], users: [] };
  },

  saveData: (data: SavedContent) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  },

  saveCurriculum: (curriculum: Curriculum) => {
    const data = storageService.getData();
    const existingIndex = data.curriculums.findIndex(c => c.id === curriculum.id);
    if (existingIndex > -1) {
      data.curriculums[existingIndex] = curriculum;
    } else {
      data.curriculums.push(curriculum);
    }
    storageService.saveData(data);
  },

  deleteCurriculum: (id: string) => {
    const data = storageService.getData();
    data.curriculums = data.curriculums.filter(c => c.id !== id);
    storageService.saveData(data);
  },

  getCurriculumsByUser: (userId: string): Curriculum[] => {
    return storageService.getData().curriculums.filter(c => c.userId === userId);
  },

  getCurriculumById: (id: string): Curriculum | undefined => {
    return storageService.getData().curriculums.find(c => c.id === id);
  }
};
