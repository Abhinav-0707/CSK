
import { GoogleGenAI, Type } from "@google/genai";
import { Curriculum, Module, Slide, TeachingNote } from '../types';

export const geminiService = {
  generateCurriculum: async (inputs: {
    title: string;
    audience: string;
    skillLevel: string;
    industry: string;
    duration: string;
    objectives: string;
  }): Promise<Partial<Curriculum>> => {
    // Create a new instance right before making an API call for the latest key
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Generate a detailed academic curriculum for a course titled "${inputs.title}".
    Target Audience: ${inputs.audience}
    Skill Level: ${inputs.skillLevel}
    Industry: ${inputs.industry}
    Duration: ${inputs.duration}
    Initial Objectives: ${inputs.objectives}

    Provide the output in strict JSON format matching this schema:
    {
      "description": "Short compelling overview",
      "modules": [
        { "title": "Module 1", "topics": ["T1", "T2"], "practicalTasks": ["Task 1"] }
      ],
      "outcomes": ["Outcome 1", "Outcome 2"],
      "assignments": ["Assignment 1"],
      "tools": ["Tool 1"],
      "qualityScore": 0-100,
      "industryAlignment": 0-100
    }`;

    const response = await ai.models.generateContent({
      // Curriculum design is a complex text task requiring pro reasoning
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING },
            modules: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  topics: { type: Type.ARRAY, items: { type: Type.STRING } },
                  practicalTasks: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              }
            },
            outcomes: { type: Type.ARRAY, items: { type: Type.STRING } },
            assignments: { type: Type.ARRAY, items: { type: Type.STRING } },
            tools: { type: Type.ARRAY, items: { type: Type.STRING } },
            qualityScore: { type: Type.NUMBER },
            industryAlignment: { type: Type.NUMBER }
          }
        }
      }
    });

    return JSON.parse(response.text || '{}');
  },

  generateSlides: async (curriculum: Curriculum): Promise<Slide[]> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Convert the following curriculum titled "${curriculum.title}" into professional teaching slides.
    Include at least 2 slides per module.
    
    Format: JSON Array of objects with title, bullets (4-6 per slide), and speakerNotes.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
              speakerNotes: { type: Type.STRING }
            }
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  },

  generateTeachingNotes: async (module: Module, courseTitle: string): Promise<TeachingNote> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Generate detailed teaching notes for the module "${module.title}" of the course "${courseTitle}".
    Include:
    1. Content breakdown
    2. Real-world examples
    3. A short case study
    
    Topics in this module: ${module.topics.join(', ')}
    
    Output JSON: { "moduleTitle": "string", "content": "markdown string", "examples": ["string"], "caseStudy": "string" }`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            moduleTitle: { type: Type.STRING },
            content: { type: Type.STRING },
            examples: { type: Type.ARRAY, items: { type: Type.STRING } },
            caseStudy: { type: Type.STRING }
          }
        }
      }
    });

    return JSON.parse(response.text || '{}');
  },

  suggestTrendingSkills: async (industry: string): Promise<string[]> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `List 5 trending high-demand skills or topics for the ${industry} industry in 2024-2025. 
    Return as a JSON array of strings.`;

    const response = await ai.models.generateContent({
      // Simple Q&A tasks use flash
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });

    return JSON.parse(response.text || '[]');
  }
};
